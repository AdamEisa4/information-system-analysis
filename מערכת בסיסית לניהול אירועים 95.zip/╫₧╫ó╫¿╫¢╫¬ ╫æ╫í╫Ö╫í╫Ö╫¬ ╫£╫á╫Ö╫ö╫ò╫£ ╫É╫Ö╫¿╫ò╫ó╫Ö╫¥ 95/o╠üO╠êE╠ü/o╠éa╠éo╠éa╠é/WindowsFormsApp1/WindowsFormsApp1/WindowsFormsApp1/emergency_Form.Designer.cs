﻿namespace GROUP30
{
    partial class emergency_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.suppliertype = new System.Windows.Forms.Label();
            this.findoptimalsupplier = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dgvSuppliers = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbSupplierType = new System.Windows.Forms.ComboBox();
            this.send_sms = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).BeginInit();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(83, 247);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 11;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(239, 247);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(75, 23);
            this.search.TabIndex = 10;
            this.search.Text = "search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // suppliertype
            // 
            this.suppliertype.AutoSize = true;
            this.suppliertype.Location = new System.Drawing.Point(103, 158);
            this.suppliertype.Name = "suppliertype";
            this.suppliertype.Size = new System.Drawing.Size(66, 13);
            this.suppliertype.TabIndex = 8;
            this.suppliertype.Text = "supplier type";
            // 
            // findoptimalsupplier
            // 
            this.findoptimalsupplier.AutoSize = true;
            this.findoptimalsupplier.Location = new System.Drawing.Point(157, 103);
            this.findoptimalsupplier.Name = "findoptimalsupplier";
            this.findoptimalsupplier.Size = new System.Drawing.Size(99, 13);
            this.findoptimalsupplier.TabIndex = 7;
            this.findoptimalsupplier.Text = "find optimal supplier";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(105, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(230, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // dgvSuppliers
            // 
            this.dgvSuppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuppliers.Location = new System.Drawing.Point(390, 131);
            this.dgvSuppliers.Name = "dgvSuppliers";
            this.dgvSuppliers.Size = new System.Drawing.Size(240, 150);
            this.dgvSuppliers.TabIndex = 14;
            this.dgvSuppliers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSuppliers_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(403, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "supplier name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(513, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "supplier phone number";
            // 
            // cmbSupplierType
            // 
            this.cmbSupplierType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplierType.FormattingEnabled = true;
            this.cmbSupplierType.Items.AddRange(new object[] {
            "Band",
            "Catering",
            "DJ",
            "Equipment",
            "Furniture",
            "Photographer",
            "Transportation",
            "Venue"});
            this.cmbSupplierType.Location = new System.Drawing.Point(201, 155);
            this.cmbSupplierType.Name = "cmbSupplierType";
            this.cmbSupplierType.Size = new System.Drawing.Size(122, 21);
            this.cmbSupplierType.TabIndex = 17;
            this.cmbSupplierType.SelectedIndexChanged += new System.EventHandler(this.cmbSupplierType_SelectedIndexChanged_1);
            // 
            // send_sms
            // 
            this.send_sms.Location = new System.Drawing.Point(471, 304);
            this.send_sms.Name = "send_sms";
            this.send_sms.Size = new System.Drawing.Size(75, 23);
            this.send_sms.TabIndex = 18;
            this.send_sms.Text = "send sms";
            this.send_sms.UseVisualStyleBackColor = true;
            this.send_sms.Click += new System.EventHandler(this.send_sms_Click);
            // 
            // emergency_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 349);
            this.Controls.Add(this.send_sms);
            this.Controls.Add(this.cmbSupplierType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvSuppliers);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.back);
            this.Controls.Add(this.search);
            this.Controls.Add(this.suppliertype);
            this.Controls.Add(this.findoptimalsupplier);
            this.Name = "emergency_Form";
            this.Text = "emergency_Form";
            this.Load += new System.EventHandler(this.emergency_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Label suppliertype;
        private System.Windows.Forms.Label findoptimalsupplier;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dgvSuppliers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbSupplierType;
        private System.Windows.Forms.Button send_sms;
    }
}