﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class login_form : Form
    {
        public login_form()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserId.Text))
            {
                MessageBox.Show("Enter User ID", "המשך", MessageBoxButtons.OK);
                txtUserId.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Enter Password", "המשך", MessageBoxButtons.OK);
                txtPassword.Focus();
                return;
            }
            User user = new User { UserID = txtUserId.Text, Password = txtPassword.Text };
            if (ApplUser.Login(user))
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else {
                txtUserId.Focus();
                return;
            }

        }

        private void login_form_Load(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.None;
        }

        private void txtUserId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
