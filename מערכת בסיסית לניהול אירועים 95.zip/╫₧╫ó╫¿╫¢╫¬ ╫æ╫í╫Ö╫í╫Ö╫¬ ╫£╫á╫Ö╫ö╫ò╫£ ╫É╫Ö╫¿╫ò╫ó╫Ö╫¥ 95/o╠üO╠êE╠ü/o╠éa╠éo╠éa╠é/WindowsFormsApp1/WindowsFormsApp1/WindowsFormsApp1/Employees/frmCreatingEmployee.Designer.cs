﻿namespace GROUP30
{
    partial class frmCreatingEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.txtEmployeeAddress = new System.Windows.Forms.TextBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtEmployeeEmail = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.lblCaption = new System.Windows.Forms.Label();
            this.txtEmployeeId = new System.Windows.Forms.TextBox();
            this.cmbEmployeeType = new System.Windows.Forms.ComboBox();
            this.cmbLanguages = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(162, 634);
            this.back.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(218, 71);
            this.back.TabIndex = 7;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(472, 634);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(218, 71);
            this.btnCreate.TabIndex = 6;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(60, 483);
            this.Address.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(132, 40);
            this.Address.TabIndex = 27;
            this.Address.Text = "Address";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(60, 410);
            this.lblType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(233, 40);
            this.lblType.TabIndex = 26;
            this.lblType.Text = "Employee Type";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.Location = new System.Drawing.Point(60, 331);
            this.PhoneNumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(233, 40);
            this.PhoneNumber.TabIndex = 25;
            this.PhoneNumber.Text = "Phone Number";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(60, 177);
            this.name.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(102, 40);
            this.name.TabIndex = 24;
            this.name.Text = "Name";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(60, 253);
            this.email.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(93, 40);
            this.email.TabIndex = 23;
            this.email.Text = "Email";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(60, 105);
            this.ID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(48, 40);
            this.ID.TabIndex = 22;
            this.ID.Text = "ID";
            // 
            // txtEmployeeAddress
            // 
            this.txtEmployeeAddress.Location = new System.Drawing.Point(308, 478);
            this.txtEmployeeAddress.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtEmployeeAddress.MaxLength = 100;
            this.txtEmployeeAddress.Name = "txtEmployeeAddress";
            this.txtEmployeeAddress.Size = new System.Drawing.Size(534, 48);
            this.txtEmployeeAddress.TabIndex = 5;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtPhoneNumber.Location = new System.Drawing.Point(308, 323);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtPhoneNumber.MaxLength = 10;
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(212, 48);
            this.txtPhoneNumber.TabIndex = 3;
            this.txtPhoneNumber.TextChanged += new System.EventHandler(this.txtPhoneNumber_TextChanged);
            this.txtPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNumber_KeyPress);
            this.txtPhoneNumber.Leave += new System.EventHandler(this.txtPhoneNumber_Leave);

            // 
            // txtEmployeeEmail
            // 
            this.txtEmployeeEmail.Location = new System.Drawing.Point(308, 253);
            this.txtEmployeeEmail.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtEmployeeEmail.MaxLength = 30;
            this.txtEmployeeEmail.Name = "txtEmployeeEmail";
            this.txtEmployeeEmail.Size = new System.Drawing.Size(212, 48);
            this.txtEmployeeEmail.TabIndex = 2;
            this.txtEmployeeEmail.TextChanged += new System.EventHandler(this.txtEmployeeEmail_TextChanged);
            this.txtEmployeeEmail.Leave += new System.EventHandler(this.txtEmployeeEmail_Leave);
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(308, 177);
            this.txtEmployeeName.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtEmployeeName.MaxLength = 20;
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(212, 48);
            this.txtEmployeeName.TabIndex = 1;
            this.txtEmployeeName.TextChanged += new System.EventHandler(this.txtEmployeeName_TextChanged);
            this.txtEmployeeName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmployeeName_KeyPress);
            // 
            // lblCaption
            // 
            this.lblCaption.AutoSize = true;
            this.lblCaption.Location = new System.Drawing.Point(312, 29);
            this.lblCaption.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(156, 40);
            this.lblCaption.TabIndex = 16;
            this.lblCaption.Text = "Employee";
            this.lblCaption.Click += new System.EventHandler(this.lblCaption_Click);
            // 
            // txtEmployeeId
            // 
            this.txtEmployeeId.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.txtEmployeeId.Location = new System.Drawing.Point(308, 100);
            this.txtEmployeeId.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtEmployeeId.MaxLength = 20;
            this.txtEmployeeId.Name = "txtEmployeeId";
            this.txtEmployeeId.Size = new System.Drawing.Size(212, 48);
            this.txtEmployeeId.TabIndex = 0;
            this.txtEmployeeId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbEmployeeType
            // 
            this.cmbEmployeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployeeType.FormattingEnabled = true;
            this.cmbEmployeeType.Location = new System.Drawing.Point(308, 410);
            this.cmbEmployeeType.Name = "cmbEmployeeType";
            this.cmbEmployeeType.Size = new System.Drawing.Size(212, 48);
            this.cmbEmployeeType.TabIndex = 4;
            // 
            // cmbLanguages
            // 
            this.cmbLanguages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLanguages.FormattingEnabled = true;
            this.cmbLanguages.Location = new System.Drawing.Point(308, 536);
            this.cmbLanguages.Name = "cmbLanguages";
            this.cmbLanguages.Size = new System.Drawing.Size(212, 48);
            this.cmbLanguages.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 536);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 40);
            this.label1.TabIndex = 29;
            this.label1.Text = "Language";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.id;
            this.pictureBox1.Location = new System.Drawing.Point(245, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 57);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GROUP30.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(741, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(130, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            // 
            // frmCreatingEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(18F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(883, 757);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cmbLanguages);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbEmployeeType);
            this.Controls.Add(this.back);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.PhoneNumber);
            this.Controls.Add(this.name);
            this.Controls.Add(this.email);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.txtEmployeeAddress);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.txtEmployeeEmail);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblCaption);
            this.Controls.Add(this.txtEmployeeId);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmCreatingEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Creating Employee";
            this.Load += new System.EventHandler(this.frmCreatingEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.TextBox txtEmployeeAddress;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtEmployeeEmail;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label lblCaption;
        private System.Windows.Forms.TextBox txtEmployeeId;
        private System.Windows.Forms.ComboBox cmbEmployeeType;
        private System.Windows.Forms.ComboBox cmbLanguages;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}