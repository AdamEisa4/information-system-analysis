﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmCreateEvent : Form
    {
        public Boolean isNew { get; set; } = true;
        private Boolean mViewOnly = false;
        public Boolean ViewOnly
        {
            set {
                mViewOnly = value;
               if (value)
                {
                    btnAddBids.Visible = false;
                    btnCreate.Visible = false;
                    btnEmergency.Visible = false;
                    cmbEventStatus.Enabled = false;
                    cmbEventTime.Enabled = false;
                    cmbEventType.Enabled = false;
                    txtBudget.ReadOnly = true;
                    dtpEventDate.Enabled = false;
                }

            }
        }
        public frmCreateEvent()
        {
            InitializeComponent();
            cmbEventStatus.SelectedIndex = 0;
            btnAddBids.Visible = false;
            btnEmergency.Visible = false;
            dgvOrders.Visible = false;
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                MessageBox.Show("Enter Customer Phone Number.", "המשך", MessageBoxButtons.OK);
                txtPhoneNumber.Focus();
                return;
            }
            if (dtpEventDate.Value.Date < DateTime.Today.Date)
            {
                MessageBox.Show("Cannot create event for past date", "המשך", MessageBoxButtons.OK);
                dtpEventDate.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtLocation.Text))
            {
                MessageBox.Show("Enter event locaton.", "המשך", MessageBoxButtons.OK);
                txtLocation.Focus();
                return;
            }
            if (string.IsNullOrEmpty(cmbEventType.Text))
            {
                MessageBox.Show("Select event type.", "המשך", MessageBoxButtons.OK);
                cmbEventType.Focus();
                return;
            }
            if (string.IsNullOrEmpty(cmbEventTime.Text))
            {
                MessageBox.Show("Select event Time.", "המשך", MessageBoxButtons.OK);
                cmbEventTime.Focus();
                return;
            }


            Event s = new Event()
            {
                eventID=txtEventId.Text,
                eventDate = dtpEventDate.Value.Date,
                budget = double.Parse(txtBudget.Text),
                eventStatus = (EVENT_STATUS)Enum.Parse(typeof(EVENT_STATUS), cmbEventStatus.Text),
                eventTime = (EVENT_TIMES)Enum.Parse(typeof(EVENT_TIMES), cmbEventTime.Text),
                eventType = (EVENT_TYPES)Enum.Parse(typeof(EVENT_TYPES), cmbEventType.Text),
                location = txtLocation.Text,
                phoneNumber=txtPhoneNumber.Text
            };
            if (isNew)
            {
                if (Event.Create_Event(s))
                {
                    MessageBox.Show("Event created successfully", "המשך", MessageBoxButtons.OK);
                }
            }
            else
            {
                if (Event.Update_Event(s))
                {
                    MessageBox.Show("Event updated successfully", "המשך", MessageBoxButtons.OK);
                }
            }
        }

        private void frmCreateEvent_Load(object sender, EventArgs e)
        {
            if (ApplUser.ActiveUser.Role == "Customer") { ViewOnly = true; }
        }
        public void ShowEvent(Event obj)
        {
            isNew = false;
            btnCreate.Text = "Update";
            lblCaption.Text = "Update Event";
            this.Text = "Update Event";
            txtBudget.Text = obj.budget.ToString();
            txtLocation.Text = obj.location;
            txtEventId.Text = obj.eventID;
            txtPhoneNumber.Text = obj.phoneNumber;
            cmbEventStatus.Text = obj.eventStatus.ToString();
            cmbEventTime.Text = obj.eventTime.ToString();
            cmbEventType.Text = obj.eventType.ToString();
            txtEventId.ReadOnly = true;
            ShowOrders();
        }
        private void ShowOrders()
        {
            if (string.IsNullOrEmpty(txtEventId.Text)) { return; }
            dgvOrders.AutoGenerateColumns = false;
            dgvOrders.ColumnHeadersVisible = true;
            dgvOrders.Columns.Clear();
            dgvOrders.SelectionMode = DataGridViewSelectionMode.FullRowSelect; 
            dgvOrders.Columns.Add("SupplierType", "Type");
            dgvOrders.Columns["SupplierType"].DataPropertyName = "SupplierType";
            dgvOrders.Columns["SupplierType"].Width = 150;
            dgvOrders.Columns.Add("supplierName", "Supplier");
            dgvOrders.Columns["supplierName"].DataPropertyName = "supplierName";
            dgvOrders.Columns["supplierName"].Width = 150;
            dgvOrders.Columns.Add("isPaid", "Paid");
            dgvOrders.Columns["isPaid"].DataPropertyName = "isPaid";
            dgvOrders.Columns["isPaid"].Width = 100;
            dgvOrders.Columns.Add("orderDescription", "service");
            dgvOrders.Columns["orderDescription"].DataPropertyName = "orderDescription";
            dgvOrders.Columns["orderDescription"].Width = 500;
            dgvOrders.DataSource = null;
            dgvOrders.DataSource = Order.get_Orders(new Order() { eventID = txtEventId.Text });
            btnAddBids.Visible = !mViewOnly;
            btnEmergency.Visible = !mViewOnly;
            dgvOrders.Visible = true;

        }
        void dgvOrders_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                if (e.Value is bool)
                {
                    bool value = (bool)e.Value;
                    e.Value = (value) ? "Yes" : "No";
                    e.FormattingApplied = true;
                }
            }
        }

        private void dgvOrders_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                Order s = (Order)((DataGridView)sender).Rows[e.RowIndex].DataBoundItem;
                if (!s.isPaid) { 
                   frmNewPayment form2 = new frmNewPayment();
                    form2.OrderID = s.orderID;
                    var result = form2.ShowDialog(this);
                        if (result == DialogResult.OK)
                        {
                            ShowOrders();
                        }

                }
                if (s.isPaid)
                {
                    frmCancelPayment form2 = new frmCancelPayment();
                    form2.PaymentID = s.paymentID;
                    var result = form2.ShowDialog(this);
                    if (result == DialogResult.OK)
                    {
                        ShowOrders();
                    }
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            emergency_Form em = new emergency_Form();
            em.ShowDialog(this);
        }

        private void btnAddBids_Click(object sender, EventArgs e)
        {
            frmAddBids _form = new frmAddBids();
            _form.EventID = txtEventId.Text;
            _form.ShowDialog(this);
            ShowOrders();
        }

        private void txtPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        }

        private void txtBudget_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }

        }

    }
}
