﻿namespace GROUP30
{
    partial class frmAddBids
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSuppliers = new System.Windows.Forms.DataGridView();
            this.cmbSupplierType = new System.Windows.Forms.ComboBox();
            this.SupplierType = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblDetails = new System.Windows.Forms.Label();
            this.txtDetails = new System.Windows.Forms.TextBox();
            this.dgvBids = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.optimal_supplier = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBids)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSuppliers
            // 
            this.dgvSuppliers.AllowUserToAddRows = false;
            this.dgvSuppliers.AllowUserToDeleteRows = false;
            this.dgvSuppliers.AllowUserToResizeColumns = false;
            this.dgvSuppliers.AllowUserToResizeRows = false;
            this.dgvSuppliers.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvSuppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuppliers.ColumnHeadersVisible = false;
            this.dgvSuppliers.Location = new System.Drawing.Point(31, 83);
            this.dgvSuppliers.Margin = new System.Windows.Forms.Padding(6);
            this.dgvSuppliers.Name = "dgvSuppliers";
            this.dgvSuppliers.ReadOnly = true;
            this.dgvSuppliers.RowHeadersVisible = false;
            this.dgvSuppliers.RowHeadersWidth = 51;
            this.dgvSuppliers.RowTemplate.Height = 24;
            this.dgvSuppliers.Size = new System.Drawing.Size(415, 210);
            this.dgvSuppliers.TabIndex = 1;
            // 
            // cmbSupplierType
            // 
            this.cmbSupplierType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplierType.FormattingEnabled = true;
            this.cmbSupplierType.Items.AddRange(new object[] {
            "Band",
            "Catering",
            "DJ",
            "Equipment",
            "Furniture",
            "Photographer",
            "Transportation",
            "Venue"});
            this.cmbSupplierType.Location = new System.Drawing.Point(222, 22);
            this.cmbSupplierType.Name = "cmbSupplierType";
            this.cmbSupplierType.Size = new System.Drawing.Size(212, 39);
            this.cmbSupplierType.TabIndex = 0;
            this.cmbSupplierType.SelectedIndexChanged += new System.EventHandler(this.cmbSupplierType_SelectedIndexChanged);
            // 
            // SupplierType
            // 
            this.SupplierType.AutoSize = true;
            this.SupplierType.Location = new System.Drawing.Point(27, 27);
            this.SupplierType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.SupplierType.Name = "SupplierType";
            this.SupplierType.Size = new System.Drawing.Size(181, 32);
            this.SupplierType.TabIndex = 38;
            this.SupplierType.Text = "Supplier Type";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(27, 323);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(76, 32);
            this.lblPrice.TabIndex = 46;
            this.lblPrice.Text = "Price";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(129, 320);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtPrice.MaxLength = 20;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(228, 41);
            this.txtPrice.TabIndex = 2;
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrice_KeyPress);
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Location = new System.Drawing.Point(27, 378);
            this.lblDetails.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(99, 32);
            this.lblDetails.TabIndex = 48;
            this.lblDetails.Text = "Details";
            // 
            // txtDetails
            // 
            this.txtDetails.Location = new System.Drawing.Point(129, 369);
            this.txtDetails.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.txtDetails.MaxLength = 300;
            this.txtDetails.Multiline = true;
            this.txtDetails.Name = "txtDetails";
            this.txtDetails.Size = new System.Drawing.Size(396, 118);
            this.txtDetails.TabIndex = 3;
            // 
            // dgvBids
            // 
            this.dgvBids.AllowUserToAddRows = false;
            this.dgvBids.AllowUserToDeleteRows = false;
            this.dgvBids.AllowUserToResizeColumns = false;
            this.dgvBids.AllowUserToResizeRows = false;
            this.dgvBids.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvBids.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBids.ColumnHeadersVisible = false;
            this.dgvBids.Location = new System.Drawing.Point(509, 83);
            this.dgvBids.Margin = new System.Windows.Forms.Padding(6);
            this.dgvBids.Name = "dgvBids";
            this.dgvBids.ReadOnly = true;
            this.dgvBids.RowHeadersVisible = false;
            this.dgvBids.RowHeadersWidth = 51;
            this.dgvBids.RowTemplate.Height = 24;
            this.dgvBids.Size = new System.Drawing.Size(588, 210);
            this.dgvBids.TabIndex = 49;
            this.dgvBids.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(690, 430);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(161, 57);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(465, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 32);
            this.label1.TabIndex = 51;
            this.label1.Text = "Available Bids:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(963, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(134, 117);
            this.button1.TabIndex = 5;
            this.button1.Text = "Create optimal Orders";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // optimal_supplier
            // 
            this.optimal_supplier.Location = new System.Drawing.Point(608, 320);
            this.optimal_supplier.Name = "optimal_supplier";
            this.optimal_supplier.Size = new System.Drawing.Size(161, 99);
            this.optimal_supplier.TabIndex = 58;
            this.optimal_supplier.Text = "find optimal supplier";
            this.optimal_supplier.UseVisualStyleBackColor = true;
            this.optimal_supplier.Visible = false;
            this.optimal_supplier.Click += new System.EventHandler(this.optimal_supplier_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(969, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 59;
            this.pictureBox1.TabStop = false;
            // 
            // frmAddBids
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 499);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.optimal_supplier);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvBids);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.txtDetails);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.cmbSupplierType);
            this.Controls.Add(this.SupplierType);
            this.Controls.Add(this.dgvSuppliers);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmAddBids";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Bids";
            this.Load += new System.EventHandler(this.frmAddBids_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuppliers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBids)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSuppliers;
        private System.Windows.Forms.ComboBox cmbSupplierType;
        private System.Windows.Forms.Label SupplierType;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.TextBox txtDetails;
        private System.Windows.Forms.DataGridView dgvBids;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button optimal_supplier;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}