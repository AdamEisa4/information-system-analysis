﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace GROUP30
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static List<Supplier> Suppliers;
        public static List<Contact_Way> Contact_Ways;
        //public static System.Collections.Generic.List<Order> Orders;


        [STAThread]

        //שיטה שמחפשת ספק ברשימה לפי תעודת זהות
        public static Supplier seekSupplier(string id)
        {
            foreach (Supplier s in Suppliers)
            {
                if (s.supplierID == id)
                    return s;
            }
            return null;
        }
        public static void initLists()//מילוי הרשימות מתוך בסיס הנתונים
        {
            SQL_CON.ConnString =  System.Configuration.ConfigurationManager.ConnectionStrings["WindowsFormsApp1.Properties.Settings.SAD_30ConnectionString"].ConnectionString;
            Contact_Ways = Contact_Way.GetContact_Ways();
            Suppliers = Supplier.get_Suppliers(new Supplier());
        }

        // public static bool EmailIsValid(string email)
        //{
        //    return Regex.IsMatch(email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        //}

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            initLists();
            Application.Run(new mainForm());
        }

    }

}
