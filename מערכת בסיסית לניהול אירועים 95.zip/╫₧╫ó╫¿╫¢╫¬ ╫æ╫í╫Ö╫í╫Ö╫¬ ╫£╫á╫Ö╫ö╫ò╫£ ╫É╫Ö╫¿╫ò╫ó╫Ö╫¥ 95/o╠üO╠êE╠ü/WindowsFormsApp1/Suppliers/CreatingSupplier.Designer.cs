﻿namespace GROUP30
{
    partial class CreatingSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IDSupplierText = new System.Windows.Forms.TextBox();
            this.lblCaption = new System.Windows.Forms.Label();
            this.NameSupplierText = new System.Windows.Forms.TextBox();
            this.EmailSupplierText = new System.Windows.Forms.TextBox();
            this.AddressSupplierText = new System.Windows.Forms.TextBox();
            this.PhoneNumberSupplierText = new System.Windows.Forms.TextBox();
            this.ID = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.SupplierType = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.cmbSupplierType = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // IDSupplierText
            // 
            this.IDSupplierText.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDSupplierText.ForeColor = System.Drawing.Color.Black;
            this.IDSupplierText.Location = new System.Drawing.Point(356, 163);
            this.IDSupplierText.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.IDSupplierText.Name = "IDSupplierText";
            this.IDSupplierText.Size = new System.Drawing.Size(212, 34);
            this.IDSupplierText.TabIndex = 0;
            this.IDSupplierText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblCaption
            // 
            this.lblCaption.AutoSize = true;
            this.lblCaption.BackColor = System.Drawing.Color.Transparent;
            this.lblCaption.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.Location = new System.Drawing.Point(255, 73);
            this.lblCaption.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(122, 34);
            this.lblCaption.TabIndex = 1;
            this.lblCaption.Text = "Supplier";
            // 
            // NameSupplierText
            // 
            this.NameSupplierText.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameSupplierText.Location = new System.Drawing.Point(356, 240);
            this.NameSupplierText.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.NameSupplierText.Name = "NameSupplierText";
            this.NameSupplierText.Size = new System.Drawing.Size(212, 34);
            this.NameSupplierText.TabIndex = 2;
            this.NameSupplierText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameSupplierText_KeyPress);
            // 
            // EmailSupplierText
            // 
            this.EmailSupplierText.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailSupplierText.Location = new System.Drawing.Point(356, 316);
            this.EmailSupplierText.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.EmailSupplierText.Name = "EmailSupplierText";
            this.EmailSupplierText.Size = new System.Drawing.Size(212, 34);
            this.EmailSupplierText.TabIndex = 3;
            this.EmailSupplierText.TextChanged += new System.EventHandler(this.EmailSupplierText_TextChanged);
            this.EmailSupplierText.Leave += new System.EventHandler(this.EmailSupplierText_Leave);
            // 
            // AddressSupplierText
            // 
            this.AddressSupplierText.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressSupplierText.Location = new System.Drawing.Point(356, 541);
            this.AddressSupplierText.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.AddressSupplierText.Name = "AddressSupplierText";
            this.AddressSupplierText.Size = new System.Drawing.Size(212, 34);
            this.AddressSupplierText.TabIndex = 6;
            // 
            // PhoneNumberSupplierText
            // 
            this.PhoneNumberSupplierText.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumberSupplierText.Location = new System.Drawing.Point(356, 386);
            this.PhoneNumberSupplierText.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.PhoneNumberSupplierText.MaxLength = 10;
            this.PhoneNumberSupplierText.Name = "PhoneNumberSupplierText";
            this.PhoneNumberSupplierText.Size = new System.Drawing.Size(212, 34);
            this.PhoneNumberSupplierText.TabIndex = 4;
            this.PhoneNumberSupplierText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNumberSupplierText_KeyPress);
            this.PhoneNumberSupplierText.Leave += new System.EventHandler(this.PhoneNumberSupplierText_Leave);
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.BackColor = System.Drawing.Color.Transparent;
            this.ID.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID.Location = new System.Drawing.Point(101, 166);
            this.ID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(33, 26);
            this.ID.TabIndex = 7;
            this.ID.Text = "ID";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(101, 314);
            this.email.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(62, 26);
            this.email.TabIndex = 8;
            this.email.Text = "email";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(101, 238);
            this.name.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(64, 26);
            this.name.TabIndex = 9;
            this.name.Text = "name";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumber.Location = new System.Drawing.Point(101, 392);
            this.PhoneNumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(153, 26);
            this.PhoneNumber.TabIndex = 10;
            this.PhoneNumber.Text = "Phone Number";
            // 
            // SupplierType
            // 
            this.SupplierType.AutoSize = true;
            this.SupplierType.BackColor = System.Drawing.Color.Transparent;
            this.SupplierType.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierType.Location = new System.Drawing.Point(101, 471);
            this.SupplierType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.SupplierType.Name = "SupplierType";
            this.SupplierType.Size = new System.Drawing.Size(137, 26);
            this.SupplierType.TabIndex = 11;
            this.SupplierType.Text = "Supplier Type";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.BackColor = System.Drawing.Color.Transparent;
            this.Address.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address.Location = new System.Drawing.Point(101, 544);
            this.Address.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(86, 26);
            this.Address.TabIndex = 12;
            this.Address.Text = "Address";
            // 
            // btnCreate
            // 
            this.btnCreate.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreate.Location = new System.Drawing.Point(350, 647);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(218, 71);
            this.btnCreate.TabIndex = 13;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.Create_Click);
            // 
            // back
            // 
            this.back.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(40, 647);
            this.back.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(218, 71);
            this.back.TabIndex = 14;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // cmbSupplierType
            // 
            this.cmbSupplierType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplierType.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSupplierType.FormattingEnabled = true;
            this.cmbSupplierType.Items.AddRange(new object[] {
            "Band",
            "Catering",
            "DJ",
            "Equipment",
            "Furniture",
            "Photographer",
            "Transportation",
            "Venue"});
            this.cmbSupplierType.Location = new System.Drawing.Point(356, 466);
            this.cmbSupplierType.Name = "cmbSupplierType";
            this.cmbSupplierType.Size = new System.Drawing.Size(212, 34);
            this.cmbSupplierType.TabIndex = 5;
            this.cmbSupplierType.SelectedIndexChanged += new System.EventHandler(this.cmbSupplierType_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::GROUP30.Properties.Resources.id;
            this.pictureBox1.Location = new System.Drawing.Point(198, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::GROUP30.Properties.Resources.latizea;
            this.pictureBox2.Location = new System.Drawing.Point(525, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(122, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // CreatingSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::GROUP30.Properties.Resources._5631800;
            this.ClientSize = new System.Drawing.Size(659, 775);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cmbSupplierType);
            this.Controls.Add(this.back);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.SupplierType);
            this.Controls.Add(this.PhoneNumber);
            this.Controls.Add(this.name);
            this.Controls.Add(this.email);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.AddressSupplierText);
            this.Controls.Add(this.PhoneNumberSupplierText);
            this.Controls.Add(this.EmailSupplierText);
            this.Controls.Add(this.NameSupplierText);
            this.Controls.Add(this.lblCaption);
            this.Controls.Add(this.IDSupplierText);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "CreatingSupplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateingSupplier";
            this.Load += new System.EventHandler(this.CreateingSupplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IDSupplierText;
        private System.Windows.Forms.Label lblCaption;
        private System.Windows.Forms.TextBox NameSupplierText;
        private System.Windows.Forms.TextBox EmailSupplierText;
        private System.Windows.Forms.TextBox AddressSupplierText;
        private System.Windows.Forms.TextBox PhoneNumberSupplierText;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label SupplierType;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.ComboBox cmbSupplierType;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}