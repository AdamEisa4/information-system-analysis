﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class CreatingSupplier : Form
    {
        public Boolean isNew { get; set; } = true;
        public CreatingSupplier()
        {
            InitializeComponent();
        }

        private void CreateingSupplier_Load(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();        }
        public void ShowSupplier(Supplier supplier)
        {
            isNew = false;
            btnCreate.Text = "Update";
            lblCaption.Text = "Update Supplier";
            this.Text = "Update Supplier";
            IDSupplierText.Text = supplier.supplierID;
            PhoneNumberSupplierText.Text = supplier.phoneNumber;
            AddressSupplierText.Text = supplier.supplierAddress;
            EmailSupplierText.Text = supplier.supplierEmail;
            NameSupplierText.Text = supplier.supplierName;
            cmbSupplierType.Text = supplier.SupplierType;
            IDSupplierText.ReadOnly = true;
        }
        private void Create_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(IDSupplierText.Text)) { 
                    MessageBox.Show("Enter Supplier ID.", "המשך", MessageBoxButtons.OK);
                IDSupplierText.Focus();
                return;
            }
            if (!IDSupplierText.Text.StartsWith("supp"))
            {
                MessageBox.Show("Supplier ID must start with supp", "המשך", MessageBoxButtons.OK);
                IDSupplierText.Focus();
                return;
            }
            if (string.IsNullOrEmpty(NameSupplierText.Text))
            {
                MessageBox.Show("Enter Supplier Name.", "המשך", MessageBoxButtons.OK);
                NameSupplierText.Focus();
                return;
            }

            Supplier s = new Supplier()
            {
                supplierID = IDSupplierText.Text,
                phoneNumber = PhoneNumberSupplierText.Text,
                supplierAddress = AddressSupplierText.Text,
                supplierEmail = EmailSupplierText.Text,
                supplierName = NameSupplierText.Text,
                SupplierType = cmbSupplierType.Text // (suplierType)Enum.Parse(typeof(suplierType), cmbSupplierType.Text)
            };
            if (isNew) { 
                if (Supplier.create_Supplier(s))
                {
                    MessageBox.Show("Supplier created successfully", "המשך", MessageBoxButtons.OK);
                }
            }
            else
            {
                if (Supplier.Update_Supplier(s))
                {
                    MessageBox.Show("Supplier updated successfully", "המשך", MessageBoxButtons.OK);
                }
            }
        }

        private void cmbSupplierType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void NameSupplierText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (e.KeyChar != 32) && (e.KeyChar != ((char)Keys.Back)))
            {
                e.Handled = true;
            }

        }

        private void EmailSupplierText_Leave(object sender, EventArgs e)
        {
            Regex mRegxExpression;
            if (EmailSupplierText.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$");

                if (!mRegxExpression.IsMatch(EmailSupplierText.Text.Trim()))
                {
                    MessageBox.Show("E-mail address format is not correct.", "המשך", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    EmailSupplierText.Focus();
                }
            }

        }
        private void PhoneNumberSupplierText_Leave(object sender, EventArgs e)
        {
            Regex mRegxExpression;
            if (PhoneNumberSupplierText.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$");

                if (!mRegxExpression.IsMatch(PhoneNumberSupplierText.Text.Trim()))
                {
                    MessageBox.Show("Phone number format is not correct.", "המשך", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    PhoneNumberSupplierText.Focus();
                }
            }
        }
        private void PhoneNumberSupplierText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        }

        private void EmailSupplierText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
