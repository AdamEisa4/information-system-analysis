﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace GROUP30
{
    public class Supplier
    {
        public string supplierID { get; set; } = "";
        public string supplierName { get; set; } = "";
        public string supplierEmail { get; set; } = "";
        public string phoneNumber { get; set; } = "";
       // public suplierType supplier_TYPE { get; set; } 
        public string supplierAddress { get; set; } = "";
        public string SupplierType { get; set; } = "";

        public static Boolean create_Supplier(Supplier supplier)
        {
            SqlCommand c = new SqlCommand("add_SUPPLIERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            //c.CommandText = "EXECUTE dbo.add_SUPPLIERS @supplierID, @supplierName , @supplierEmail, @phoneNumber, @SUPPLIER_TYPE, @supplierAddress";
            c.Parameters.AddWithValue("@supplierID", supplier.supplierID);
            c.Parameters.AddWithValue("@supplierName", supplier.supplierName);
            c.Parameters.AddWithValue("@supplierEmail", supplier.supplierEmail);
            c.Parameters.AddWithValue("@phoneNumber", supplier.phoneNumber);
            c.Parameters.AddWithValue("@SUPPLIER_TYPE", supplier.SupplierType);
            c.Parameters.AddWithValue("@supplierAddress", supplier.supplierAddress);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Update_Supplier(Supplier supplier)
        {
            SqlCommand c = new SqlCommand("update_SUPPLIERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            //c.CommandText = "dbo.udate_SUPPLIERS @supplierID, @supplierName, @supplierEmail, @phoneNumber, @SUPPLIER_TYPE, @supplierAddress";
            c.Parameters.AddWithValue("@supplierID", supplier.supplierID);
            c.Parameters.AddWithValue("@supplierName", supplier.supplierName);
            c.Parameters.AddWithValue("@supplierEmail", supplier.supplierEmail);
            c.Parameters.AddWithValue("@phoneNumber", supplier.phoneNumber);
            c.Parameters.AddWithValue("@SUPPLIER_TYPE", supplier.SupplierType);
            c.Parameters.AddWithValue("@supplierAddress", supplier.supplierAddress);
            return SQL_CON.execute_non_query(c, false);
        }

        public static List<Supplier> get_Suppliers(Supplier supplier)
        {
            SqlCommand c = new SqlCommand("Get_SUPPLIERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@supplierID", supplier.supplierID);
            c.Parameters.AddWithValue("@supplierName", supplier.supplierName);
            c.Parameters.AddWithValue("@supplierEmail", supplier.supplierEmail);
            c.Parameters.AddWithValue("@supplierType", supplier.SupplierType);

            c.Parameters.AddWithValue("@phoneNumber", supplier.phoneNumber);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Supplier>  Suppliers = new List<Supplier>();
            if (rdr.HasRows) { 
                while (rdr.Read())
                {
                    //suplierType st = (suplierType)Enum.Parse(typeof(suplierType), rdr["SUPPLIER_TYPE"].ToString());
                    Supplier s = new Supplier()
                    {
                        phoneNumber = rdr["phoneNumber"].ToString(),
                        supplierAddress = rdr["supplierAddress"].ToString(),
                        supplierEmail = rdr["supplierEmail"].ToString(),
                        supplierID = rdr["supplierID"].ToString(),
                        supplierName = rdr["supplierName"].ToString(),
                        SupplierType = rdr["SUPPLIER_TYPE"].ToString()
                    };
                    Suppliers.Add(s);
                }
            }
            return Suppliers;
        }
    }
}