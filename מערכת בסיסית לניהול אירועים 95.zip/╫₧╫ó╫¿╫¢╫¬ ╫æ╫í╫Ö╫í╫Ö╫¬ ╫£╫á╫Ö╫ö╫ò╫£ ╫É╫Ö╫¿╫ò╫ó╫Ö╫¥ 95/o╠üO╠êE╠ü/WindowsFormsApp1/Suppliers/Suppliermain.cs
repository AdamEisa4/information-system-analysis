﻿using System;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class Suppliermain : Form
    {
        public Suppliermain()
        {
            InitializeComponent();
        }


        private void createNewSupplier_Click(object sender, EventArgs e)
        {
            CreatingSupplier form2 = new CreatingSupplier();
            form2.ShowDialog(this);

        }

        private void SearchSupplier_Click(object sender, EventArgs e)
        {
            SearchingSupplier SearchForm = new SearchingSupplier();
            SearchForm.ShowDialog(this);
        }

        private void Suppliermain_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
