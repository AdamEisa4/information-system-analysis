﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class SearchingSupplier : Form
    {
        public SearchingSupplier()
        {
            InitializeComponent();
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                MessageBox.Show("Enter a reaserch text", "המשך", MessageBoxButtons.OK);
                txtSearch.Focus();
                return;
            }
            Supplier supplier = new Supplier();
            if (rbID.Checked) { supplier.supplierID = txtSearch.Text; }
            if (rbName.Checked) { supplier.supplierName = txtSearch.Text; }
            if (rbPhone.Checked) { supplier.phoneNumber = txtSearch.Text; }

            dgvSuppliers.AutoGenerateColumns = false;
            dgvSuppliers.Columns.Clear();
            dgvSuppliers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSuppliers.ColumnHeadersVisible = true;
            dgvSuppliers.Columns.Add("supplierID", "Id");
            dgvSuppliers.Columns["supplierID"].DataPropertyName = "supplierID";
            dgvSuppliers.Columns["supplierID"].Width = 100;
            dgvSuppliers.Columns.Add("supplierName", "Name");
            dgvSuppliers.Columns["supplierName"].DataPropertyName = "supplierName";
            dgvSuppliers.Columns["supplierName"].Width = 300;
            dgvSuppliers.DataSource = null;
            dgvSuppliers.DataSource = Supplier.get_Suppliers(supplier);
            if (dgvSuppliers.Rows.Count == 0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void SearchingSupplier_Load(object sender, EventArgs e)
        {
            rbID.Checked = true;
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvSuppliers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 )
            {
                Supplier s = (Supplier) ((DataGridView)sender).Rows[e.RowIndex].DataBoundItem;
                CreatingSupplier form2 = new CreatingSupplier();
                form2.ShowSupplier(s);
                form2.ShowDialog();
            }

        }

        private void dgvSuppliers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
