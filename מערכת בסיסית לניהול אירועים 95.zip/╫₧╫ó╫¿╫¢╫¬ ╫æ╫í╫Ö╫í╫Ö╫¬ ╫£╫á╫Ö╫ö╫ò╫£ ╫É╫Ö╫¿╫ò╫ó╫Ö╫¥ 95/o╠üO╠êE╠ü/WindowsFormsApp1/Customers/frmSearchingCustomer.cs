﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class SearchingCustomer : Form
    {
        public SearchingCustomer()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                MessageBox.Show("Enter a reaserch text", "המשך", MessageBoxButtons.OK);
                txtSearch.Focus();
                return;
            }
            Customer customer = new Customer();
            if (rbName.Checked) { customer.customerName = txtSearch.Text; }
            if (rbPhone.Checked) { customer.phoneNumber = txtSearch.Text; }

            dgvCustomers.AutoGenerateColumns = false;
            dgvCustomers.Columns.Clear();
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.ColumnHeadersVisible = true;
            dgvCustomers.Columns.Add("PhoneNumber", "Phone");
            dgvCustomers.Columns["PhoneNumber"].DataPropertyName = "phoneNumber";
            dgvCustomers.Columns["PhoneNumber"].Width = 100;
            dgvCustomers.Columns.Add("customerName", "Name");
            dgvCustomers.Columns["customerName"].DataPropertyName = "customerName";
            dgvCustomers.Columns["customerName"].Width = 300;
            dgvCustomers.DataSource = null;
            dgvCustomers.DataSource = Customer.get_Customers(customer);
            if (dgvCustomers.Rows.Count==0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void SearchingCustomer_Load(object sender, EventArgs e)
        {
            rbName.Checked = true;
        }

        private void dgvCustomers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                Customer s = (Customer)((DataGridView)sender).Rows[e.RowIndex].DataBoundItem;
                CreatingCustomer form2 = new CreatingCustomer();
                form2.ShowCustomer(s);
                form2.ShowDialog();
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void dgvCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void rbName_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
