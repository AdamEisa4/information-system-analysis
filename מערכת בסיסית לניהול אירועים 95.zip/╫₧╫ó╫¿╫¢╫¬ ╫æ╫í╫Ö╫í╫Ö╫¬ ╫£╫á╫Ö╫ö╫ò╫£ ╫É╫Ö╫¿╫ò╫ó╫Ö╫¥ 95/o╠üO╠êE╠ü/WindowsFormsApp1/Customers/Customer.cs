﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30
{
    //public enum CONTACT_WAYS
    //{
    //    Phone,
    //    Email,
    //}

    public class Contact_Way
    {
        public string Title { get; set; }

        public static List<Contact_Way> GetContact_Ways()
        {
            SqlCommand c = new SqlCommand("Select * from CONTACT_WAYS");
            c.CommandType = System.Data.CommandType.Text;
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Contact_Way> _list = new List<Contact_Way>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Contact_Way s = new Contact_Way()
                    {
                        Title = rdr["contactWay"].ToString()
                    };
                    _list.Add(s);
                }
            }
            return _list;
        }

    }
    public class Customer
    {
        public string phoneNumber { get; set; } = "";
        public string customerName { get; set; } = "";
        public string email { get; set; } = "";
        public string contactWay { get; set; } = "";

        public static Boolean Create_Customer(Customer customer)
        {
            SqlCommand c = new SqlCommand("add_CUSTOMERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@phoneNumber", customer.phoneNumber);
            c.Parameters.AddWithValue("@customerName", customer.customerName);
            c.Parameters.AddWithValue("@email", customer.email);
            c.Parameters.AddWithValue("@contactWay", customer.contactWay);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Update_Customer(Customer customer)
        {
            SqlCommand c = new SqlCommand("udate_CUSTOMERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@phoneNumber", customer.phoneNumber);
            c.Parameters.AddWithValue("@customerName", customer.customerName);
            c.Parameters.AddWithValue("@email", customer.email);
            c.Parameters.AddWithValue("@contactWay", customer.contactWay);
            return SQL_CON.execute_non_query(c, false);
        }
        public static List<Customer> get_Customers(Customer customer)
        {
            SqlCommand c = new SqlCommand("Get_CUSTOMERS");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@phoneNumber", customer.phoneNumber);
            c.Parameters.AddWithValue("@customerName", customer.customerName);
            c.Parameters.AddWithValue("@email", customer.email);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Customer> customers = new List<Customer>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Customer s = new Customer()
                    {
                        phoneNumber = rdr["phoneNumber"].ToString(),
                        customerName = rdr["customerName"].ToString(),
                        email = rdr["email"].ToString(),
                    };
                    customers.Add(s);
                }
            }
            return customers;
        }
    }
}
