﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmNewPayment : Form
    {
        public string OrderID   
        {
            get { return txtOrderID.Text; }  
            set { txtOrderID.Text = value; } 
        }
        public frmNewPayment()
        {
            InitializeComponent();
            this.DialogResult = DialogResult.None;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment()
            {
                orderID = txtOrderID.Text,
                cardcvv = txtCCV.Text,
                cardnumber = txtCardNumber.Text,
                cardvaliditymonth = int.Parse(cmbMonth.Text),
                cardvalidityyear = int.Parse(txtYear.Text),
                paymentType = "Credit Card"
            };
            string _err = payment.isValid();
            if (!string.IsNullOrEmpty(_err))
            {
                MessageBox.Show(_err, "המשך", MessageBoxButtons.OK);
                return;
            }

            if (Payment.CreatePayment(payment))
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void frmNewPayment_Load(object sender, EventArgs e)
        {

        }

        private void txtCardNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        }

        private void txtCCV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }

        }

        private void txtCardNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void lblValidity_Click(object sender, EventArgs e)
        {

        }
    }
}
