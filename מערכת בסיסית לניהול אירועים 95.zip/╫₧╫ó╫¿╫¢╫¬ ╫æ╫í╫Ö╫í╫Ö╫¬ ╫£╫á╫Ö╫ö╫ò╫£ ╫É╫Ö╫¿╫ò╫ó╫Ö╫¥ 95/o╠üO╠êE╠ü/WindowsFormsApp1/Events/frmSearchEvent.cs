﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmSearchEvent : Form
    {
        public frmSearchEvent()
        {
            InitializeComponent();
        }
        private string mCustomerPhoneNumber = "";
        private string mSupplierID = "";
        public string CustomerPhoneNumber {
            get { return mCustomerPhoneNumber; }
            set { mCustomerPhoneNumber = value;
                rbCustomer.Visible = false;
                btnSearch_Click(new object(), new EventArgs());
            }
        }
        public string SupplierID {
            get { return mSupplierID; }
            set
            {
                mSupplierID = value;
                rbSupplier.Visible = false;
                btnSearch_Click(new object(), new EventArgs());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text) && string.IsNullOrEmpty( CustomerPhoneNumber) && string.IsNullOrEmpty(SupplierID))
            {
                MessageBox.Show("Enter a reaserch text", "המשך", MessageBoxButtons.OK);
                txtSearch.Focus();
                return;
            }
            Event obj = new Event();
            if (rbID.Checked) { obj.eventID = txtSearch.Text; }
            if (rbCustomer.Checked) { obj.phoneNumber = txtSearch.Text; }
            if (rbSupplier.Checked) { obj.SearchSupplierID = txtSearch.Text; }
            if (!string.IsNullOrEmpty( CustomerPhoneNumber)) { obj.phoneNumber = CustomerPhoneNumber; }
            if (!string.IsNullOrEmpty(SupplierID)) { obj.SearchSupplierID = SupplierID; }


            dgvEvents.AutoGenerateColumns = false;
            dgvEvents.Columns.Clear();
            dgvEvents.ColumnHeadersVisible = true;
            dgvEvents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEvents.Columns.Add("EventID", "ID");
            dgvEvents.Columns["EventID"].DataPropertyName = "eventID";
            dgvEvents.Columns["EventID"].Width = 100;
            dgvEvents.Columns.Add("customerName", "Customer Name");
            dgvEvents.Columns["customerName"].DataPropertyName = "customerName";
            dgvEvents.Columns["customerName"].Width = 200;
            dgvEvents.Columns.Add("Location", "Location");
            dgvEvents.Columns["Location"].DataPropertyName = "location";
            dgvEvents.Columns["Location"].Width = 300;
            dgvEvents.DataSource = null;
            dgvEvents.DataSource = Event.get_Events(obj);
            if (dgvEvents.Rows.Count == 0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvEvents_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                Event s = (Event)((DataGridView)sender).Rows[e.RowIndex].DataBoundItem;
                frmCreateEvent form2 = new frmCreateEvent();
                form2.ShowEvent(s);
                form2.ShowDialog();
            }

        }

        private void frmSearchEvent_Load(object sender, EventArgs e)
        {
            rbID.Checked = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
