﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30
{
    class shift
    {
        public string employeeId { get; set; } = "";
        public DateTime availableDate { get; set; }
        public string eventTime { get; set; } = "";
        public static List<shift> get_Shifts(string id)
        {
            SqlCommand c = new SqlCommand("Get_EmployeeShift");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", id);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<shift> _shifts = new List<shift>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    shift s = new shift()
                    {
                        employeeId = rdr["employeeId"].ToString(),
                        availableDate = DateTime.Parse(rdr["avaliableAtDate"].ToString()),
                        eventTime= rdr["eventTime"].ToString()

                    };
                    _shifts.Add(s);
                }
            }
            return _shifts;
        }

        public static Boolean Create_Shift(shift obj)
        {
            SqlCommand c = new SqlCommand("add_EmployeeShift");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", obj.employeeId);
            c.Parameters.AddWithValue("@availableAtDate", obj.availableDate);
            c.Parameters.AddWithValue("@eventTime", obj.eventTime);

            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Remove_Shift(shift obj)
        {
            SqlCommand c = new SqlCommand("remove_EmployeeShift");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", obj.employeeId);
            c.Parameters.AddWithValue("@availableAtDate", obj.availableDate);
            c.Parameters.AddWithValue("@eventTime", obj.eventTime);

            return SQL_CON.execute_non_query(c, false);
        }


    }
}
