﻿namespace GROUP30
{
    partial class find_optimal_supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.findoptimalsupplier = new System.Windows.Forms.Label();
            this.suppliertype = new System.Windows.Forms.Label();
            this.eventID = new System.Windows.Forms.Label();
            this.search = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbSupplierType = new System.Windows.Forms.ComboBox();
            this.logo = new System.Windows.Forms.PictureBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // findoptimalsupplier
            // 
            this.findoptimalsupplier.AutoSize = true;
            this.findoptimalsupplier.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findoptimalsupplier.Location = new System.Drawing.Point(131, 57);
            this.findoptimalsupplier.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.findoptimalsupplier.Name = "findoptimalsupplier";
            this.findoptimalsupplier.Size = new System.Drawing.Size(196, 23);
            this.findoptimalsupplier.TabIndex = 0;
            this.findoptimalsupplier.Text = "find optimal supplier";
            this.findoptimalsupplier.Click += new System.EventHandler(this.label1_Click);
            // 
            // suppliertype
            // 
            this.suppliertype.AutoSize = true;
            this.suppliertype.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suppliertype.Location = new System.Drawing.Point(53, 194);
            this.suppliertype.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.suppliertype.Name = "suppliertype";
            this.suppliertype.Size = new System.Drawing.Size(131, 26);
            this.suppliertype.TabIndex = 1;
            this.suppliertype.Text = "supplier type";
            // 
            // eventID
            // 
            this.eventID.AutoSize = true;
            this.eventID.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eventID.Location = new System.Drawing.Point(62, 127);
            this.eventID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.eventID.Name = "eventID";
            this.eventID.Size = new System.Drawing.Size(90, 26);
            this.eventID.TabIndex = 2;
            this.eventID.Text = "event ID";
            this.eventID.Click += new System.EventHandler(this.label2_Click);
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(265, 271);
            this.search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(112, 37);
            this.search.TabIndex = 3;
            this.search.Text = "search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(118, 271);
            this.back.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(112, 37);
            this.back.TabIndex = 4;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(215, 128);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(192, 28);
            this.textBox1.TabIndex = 5;
            // 
            // cmbSupplierType
            // 
            this.cmbSupplierType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplierType.FormattingEnabled = true;
            this.cmbSupplierType.Items.AddRange(new object[] {
            "Band",
            "Catering",
            "DJ",
            "Equipment",
            "Furniture",
            "Photographer",
            "Transportation",
            "Venue"});
            this.cmbSupplierType.Location = new System.Drawing.Point(215, 194);
            this.cmbSupplierType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbSupplierType.Name = "cmbSupplierType";
            this.cmbSupplierType.Size = new System.Drawing.Size(192, 29);
            this.cmbSupplierType.TabIndex = 6;
            // 
            // logo
            // 
            this.logo.Image = global::GROUP30.Properties.Resources.logo;
            this.logo.Location = new System.Drawing.Point(382, 3);
            this.logo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(104, 39);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 13;
            this.logo.TabStop = false;
            // 
            // find_optimal_supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 332);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.cmbSupplierType);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.back);
            this.Controls.Add(this.search);
            this.Controls.Add(this.eventID);
            this.Controls.Add(this.suppliertype);
            this.Controls.Add(this.findoptimalsupplier);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "find_optimal_supplier";
            this.Text = "find_optimal_supplier";
            this.Load += new System.EventHandler(this.find_optimal_supplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label findoptimalsupplier;
        private System.Windows.Forms.Label suppliertype;
        private System.Windows.Forms.Label eventID;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ComboBox cmbSupplierType;
        private System.Windows.Forms.PictureBox logo;
    }
}