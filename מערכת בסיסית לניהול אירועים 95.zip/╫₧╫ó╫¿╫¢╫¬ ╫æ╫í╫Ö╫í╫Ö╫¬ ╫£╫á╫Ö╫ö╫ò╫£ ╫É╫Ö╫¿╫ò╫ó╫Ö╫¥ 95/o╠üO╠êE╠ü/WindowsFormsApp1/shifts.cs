﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmShift : Form
    {
        public frmShift()
        {
            InitializeComponent();
            cmbEventTime.SelectedIndex = 0;
        }


        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void shifts_Load(object sender, EventArgs e)
        {
            txtEmployeeID.Text = ApplUser.ActiveUser.UserID;
            txtEmployeeName.Text = ApplUser.ActiveUser.UserName;
            showShifts();
        }

        private void addbutton_Click(object sender, EventArgs e)
        {
            if (dtpAvailableDate.Value.Date< DateTime.Today.Date)
            {
                MessageBox.Show("Cannot enter past date", "המשך", MessageBoxButtons.OK);
                dtpAvailableDate.Focus();
                return;

            }
            shift s = new shift() { employeeId = ApplUser.ActiveUser.UserID,
                                    availableDate = dtpAvailableDate.Value.Date,
                                    eventTime=cmbEventTime.Text};
            if (shift.Create_Shift(s))
            {
                showShifts();
            }
        }
        private void showShifts()
        {
            dgvShifts.AutoGenerateColumns = false;
            dgvShifts.ColumnHeadersVisible = true;
            dgvShifts.Columns.Clear();
            dgvShifts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvShifts.Columns.Add("availableDate", "Date");
            dgvShifts.Columns["availableDate"].DataPropertyName = "availableDate";
            dgvShifts.Columns["availableDate"].Width = 120;
            dgvShifts.Columns.Add("eventTime", "Time");
            dgvShifts.Columns["eventTime"].DataPropertyName = "eventTime";
            dgvShifts.Columns["eventTime"].Width = 150;
            dgvShifts.DataSource = null;
            dgvShifts.DataSource = shift.get_Shifts(ApplUser.ActiveUser.UserID);
        }

        private void remove_Click(object sender, EventArgs e)
        {
            if (dgvShifts.SelectedRows.Count == 0) { return; } 

            shift s = (shift)dgvShifts.SelectedRows[0].DataBoundItem;
            if (shift.Remove_Shift(s))
            {
                showShifts();
            }

        }
    }
}
