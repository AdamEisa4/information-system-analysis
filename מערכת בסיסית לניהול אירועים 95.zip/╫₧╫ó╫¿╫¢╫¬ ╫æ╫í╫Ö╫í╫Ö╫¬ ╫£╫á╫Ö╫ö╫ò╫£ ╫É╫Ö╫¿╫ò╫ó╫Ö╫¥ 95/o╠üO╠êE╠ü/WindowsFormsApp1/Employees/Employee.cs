﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30
{
    public class Employee
    {
        public string employeeId { get; set; } = "";
        public string employeeName { get; set; } = "";
        public string phoneNumber { get; set; } = "";
        public string employeeAddress { get; set; } = "";
        public string employeeEmail { get; set; } = "";
        public string languages { get; set; } = "";
        public string employeeType { get; set; } = ""; 



        public string isValid()
        {
            if(this.employeeId.Length != 6) { return "Invalid employeeID"; }
            if(this.phoneNumber.Length >=10 && this.phoneNumber.Length <= 13) { return "Invalid employeeID";}
            return "";
            
        }

        public static Boolean Create_Employee(Employee employee)
        {
            SqlCommand c = new SqlCommand("add_EMPLOYEES");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", employee.employeeId);
            c.Parameters.AddWithValue("@employeeName", employee.employeeName);
            c.Parameters.AddWithValue("@phoneNumber", employee.phoneNumber);
            c.Parameters.AddWithValue("@employeeAddress", employee.employeeAddress);
            c.Parameters.AddWithValue("@employeeEmail", employee.employeeEmail);
            c.Parameters.AddWithValue("@languages", employee.languages);
            c.Parameters.AddWithValue("@employeeType", employee.employeeType);
            return SQL_CON.execute_non_query(c, false);
        }
        public static Boolean Update_Employee(Employee employee)
        {
            SqlCommand c = new SqlCommand("update_EMPLOYEES");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", employee.employeeId);
            c.Parameters.AddWithValue("@employeeName", employee.employeeName);
            c.Parameters.AddWithValue("@phoneNumber", employee.phoneNumber);
            c.Parameters.AddWithValue("@employeeAddress", employee.employeeAddress);
            c.Parameters.AddWithValue("@employeeEmail", employee.employeeEmail);
            c.Parameters.AddWithValue("@languages", employee.languages);
            c.Parameters.AddWithValue("@employeeType", employee.employeeType);
            return SQL_CON.execute_non_query(c, false);
        }
        public static List<Employee> get_Employees(Employee employee)
        {
            SqlCommand c = new SqlCommand("Get_EMPLOYEES");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@employeeID", employee.employeeId);
            c.Parameters.AddWithValue("@employeeName", employee.employeeName);
            c.Parameters.AddWithValue("@phoneNumber", employee.phoneNumber);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<Employee> employees = new List<Employee>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Employee s = new Employee()
                    {
                        employeeId = rdr["employeeId"].ToString(),
                        phoneNumber = rdr["phoneNumber"].ToString(),
                        employeeAddress = rdr["employeeAddress"].ToString(),
                        employeeEmail = rdr["employeeEmail"].ToString(),
                        employeeName = rdr["employeeName"].ToString(),
                        employeeType = rdr["employeeType"].ToString(),
                        languages = rdr["languages"].ToString(),
                    };
                    employees.Add(s);
                }
            }
            return employees;
        }

    }
    //public enum LANGUAGES
    //{
    //    Hebrew,
    //    Italian,
    //    Russian,
    //    English,

    //}
    //public enum EMPLOYEE_TYPE
    //{
    //    CEO,
    //    SimpleEmployee,
    //    EventManager,
    //}
    public class EMPLOYEE_TYPE
    {
        public string Title { get; set; }

        public static List<EMPLOYEE_TYPE> GetEmployeeTypes()
        {
            SqlCommand c = new SqlCommand("Select * from EMPLOYEE_TYPE");
            c.CommandType = System.Data.CommandType.Text;
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<EMPLOYEE_TYPE> _list = new List<EMPLOYEE_TYPE>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    EMPLOYEE_TYPE s = new EMPLOYEE_TYPE()
                    {
                        Title = rdr["employeeType"].ToString()
                    };
                    _list.Add(s);
                }
            }
            return _list;
        }

    }
    public class LANGUAGES
    {
        public string Title { get; set; }

        public static List<LANGUAGES> GetLanguages()
        {
            SqlCommand c = new SqlCommand("Select * from LANGUAGES");
            c.CommandType = System.Data.CommandType.Text;
            SqlDataReader rdr = SQL_CON.execute_query(c);

            List<LANGUAGES> _list = new List<LANGUAGES>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    LANGUAGES s = new LANGUAGES()
                    {
                        Title = rdr["languages"].ToString()
                    };
                    _list.Add(s);
                }
            }
            return _list;
        }

    }
}
