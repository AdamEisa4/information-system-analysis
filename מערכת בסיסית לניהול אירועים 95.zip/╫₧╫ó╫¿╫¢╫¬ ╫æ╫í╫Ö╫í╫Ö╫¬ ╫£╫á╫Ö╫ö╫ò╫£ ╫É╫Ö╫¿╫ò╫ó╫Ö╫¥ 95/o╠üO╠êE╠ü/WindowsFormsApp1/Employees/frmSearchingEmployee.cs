﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmSearchingEmployee : Form
    {
        public frmSearchingEmployee()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                MessageBox.Show("Enter a reaserch text", "המשך", MessageBoxButtons.OK);
                txtSearch.Focus();
                return;
            }

            Employee employee = new Employee();
            if (rbID.Checked) { employee.employeeId = txtSearch.Text; }
            if (rbName.Checked) { employee.employeeName = txtSearch.Text; }
            if (rbPhone.Checked) { employee.phoneNumber = txtSearch.Text; }

            dgvEmployees.AutoGenerateColumns = false;
            dgvEmployees.Columns.Clear();
            dgvEmployees.ColumnHeadersVisible = true;
            dgvEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmployees.Columns.Add("employeeId", "Id");
            dgvEmployees.Columns["employeeId"].DataPropertyName = "employeeId";
            dgvEmployees.Columns["employeeId"].Width = 100;
            dgvEmployees.Columns.Add("employeeName", "Name");
            dgvEmployees.Columns["employeeName"].DataPropertyName = "employeeName";
            dgvEmployees.Columns["employeeName"].Width = 300;
            dgvEmployees.DataSource = null;
            dgvEmployees.DataSource = Employee.get_Employees(employee);
            if (dgvEmployees.Rows.Count == 0) { MessageBox.Show("Record not found.", "המשך", MessageBoxButtons.OK); }

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmSearchingEmployee_Load(object sender, EventArgs e)
        {
            rbID.Checked = true;
        }

        private void dgvEmployees_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                Employee s = (Employee)((DataGridView)sender).Rows[e.RowIndex].DataBoundItem;
                frmCreatingEmployee form2 = new frmCreatingEmployee();
                form2.ShowEmployee(s);
                form2.ShowDialog();
            }
        }

        private void dgvEmployees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
