﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP30
{
    public partial class frmCreatingEmployee : Form
    {
        public Boolean isNew { get; set; } = true;

        public frmCreatingEmployee()
        {
            InitializeComponent();
            cmbEmployeeType.DataSource = EMPLOYEE_TYPE.GetEmployeeTypes();
            cmbEmployeeType.DisplayMember = "Title";
            cmbLanguages.DataSource = LANGUAGES.GetLanguages();
            cmbLanguages.DisplayMember = "Title";
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

            //if (Program.EmailIsValid(txtEmployeeEmail.Text))
            //{
            //    MessageBox.Show("Enter a valid Employee Email.!!!!!!!!!!", "המשך", MessageBoxButtons.OK);
            //    txtEmployeeEmail.Focus();
            //    return;
            //}
            if (string.IsNullOrEmpty(txtEmployeeId.Text))
            {
                MessageBox.Show("Enter Employee ID.", "המשך", MessageBoxButtons.OK);
                txtEmployeeId.Focus();
                return;
            }
            if (!txtEmployeeId.Text.StartsWith("emp"))
            {
                MessageBox.Show("Employee ID must start with emp", "המשך", MessageBoxButtons.OK);
                txtEmployeeId.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtEmployeeName.Text))
            {
                MessageBox.Show("Enter Employee Name.", "המשך", MessageBoxButtons.OK);
                txtEmployeeName.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtEmployeeEmail.Text))
            {
                MessageBox.Show("Enter Employee Email.", "המשך", MessageBoxButtons.OK);
                txtEmployeeEmail.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtPhoneNumber.Text))
            {
                MessageBox.Show("Enter Employee Phone number.", "המשך", MessageBoxButtons.OK);
                txtPhoneNumber.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtEmployeeAddress.Text))
            {
                MessageBox.Show("Enter Employee Address.", "המשך", MessageBoxButtons.OK);
                txtEmployeeAddress.Focus();
                return;
            }

     

            Employee s = new Employee()
            {
                employeeId = txtEmployeeId.Text,
                employeeAddress = txtEmployeeAddress.Text,
                employeeEmail=txtEmployeeEmail.Text,
                employeeName=txtEmployeeName.Text,
                employeeType= cmbEmployeeType.Text,
                languages=cmbLanguages.Text,
                phoneNumber=txtPhoneNumber.Text
            };
            if (isNew)
            {
                if (Employee.Create_Employee(s))
                {
                    MessageBox.Show("Employee created successfully", "המשך", MessageBoxButtons.OK);
                }
            }
            else
            {
                if (Employee.Update_Employee(s))
                {
                    MessageBox.Show("Employee updated successfully", "המשך", MessageBoxButtons.OK);
                }
            }

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCreatingEmployee_Load(object sender, EventArgs e)
        {

        }

        public void ShowEmployee(Employee employee)
        {
            isNew = false;
            btnCreate.Text = "Update";
            lblCaption.Text = "Update Employee";
            this.Text = "Update Employee";
            txtEmployeeId.Text = employee.employeeId;
            txtEmployeeAddress.Text = employee.employeeAddress;
            txtEmployeeEmail.Text = employee.employeeEmail;
            txtEmployeeName.Text = employee.employeeName;
            cmbEmployeeType.Text = employee.employeeType;
            txtPhoneNumber.Text = employee.phoneNumber;
            cmbLanguages.Text = employee.languages;
            txtEmployeeId.ReadOnly = true;
        }

        private void lblCaption_Click(object sender, EventArgs e)
        {

        }

        private void txtEmployeeName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (e.KeyChar != 32) && (e.KeyChar != ((char)Keys.Back)))
            {
                e.Handled = true;
            }
        }



        private void txtEmployeeEmail_Leave(object sender, EventArgs e)
        {
            Regex mRegxExpression;
            if (txtEmployeeEmail.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$");

                if (!mRegxExpression.IsMatch(txtEmployeeEmail.Text.Trim()))
                {
                    MessageBox.Show("E-mail address format is not correct.", "המשך", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmployeeEmail.Focus();
                }
            }
        }


        private void txtPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
        private void txtPhoneNumber_Leave(object sender, EventArgs e)
        {
            Regex mRegxExpression;
            if (txtPhoneNumber.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$");

                if (!mRegxExpression.IsMatch(txtPhoneNumber.Text.Trim()))
                {
                    MessageBox.Show("Phone number format is not correct.", "המשך", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPhoneNumber.Focus();
                }
            }
        }
        private void txtPhoneNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeEmail_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
