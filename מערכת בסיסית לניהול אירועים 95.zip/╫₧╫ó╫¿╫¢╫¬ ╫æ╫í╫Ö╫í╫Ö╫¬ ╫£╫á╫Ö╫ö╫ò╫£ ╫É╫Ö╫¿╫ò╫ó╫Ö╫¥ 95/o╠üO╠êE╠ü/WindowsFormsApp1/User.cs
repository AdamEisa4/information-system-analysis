﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GROUP30
{
    public class User
    {
        public  string UserID { get; set; } ="";
        public  string Password { get; set; }
        public  string UserName { get; set; } = "";

        public string Role { get; set; } = "";

    }
    public class ApplUser
    {
        public static User ActiveUser { get; set; } = new User();
        public static Boolean Login(User obj)
        {
            SqlCommand c = new SqlCommand("ValidateLogin");
            c.CommandType = System.Data.CommandType.StoredProcedure;
            c.Parameters.AddWithValue("@UserID", obj.UserID);
            c.Parameters.AddWithValue("@Password", obj.Password);
            SqlDataReader rdr = SQL_CON.execute_query(c);

            if (rdr!=null && rdr.HasRows)
            {
                while (rdr.Read())
                {
                    ActiveUser.UserID = rdr["UserID"].ToString();
                    ActiveUser.UserName = rdr["UserName"].ToString();
                    ActiveUser.Role = rdr["Role"].ToString();
                }
                return true;
            }
            return false;
        }
    }
}
